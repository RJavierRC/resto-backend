package mx.edu.resto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
