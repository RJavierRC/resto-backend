package mx.edu.resto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestoApiApplication.class, args);
	}

}
